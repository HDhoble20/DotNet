export const Footer = () => {
  return (
    <>
        <p className="text-center">&copy; All Rigths Reserved by Infoway Pvt. Ltd.</p>
    </>
  )
}
