
export const Home = () => {
  return (
    <>
      <h1>Welcome To Infoway Frontend App!</h1> 
      <hr />
      <h6>Designed and Developed by CDAC Students!</h6>       
    </>
  )
}