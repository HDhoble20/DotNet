import { useState } from 'react'

import './App.css'
import Header from './Components/Header/header'
import Footer from './Components/Footer/footer'
import Home from './Components/Home/Home'
import LayOut from './LayOut'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
     {/* <h1 className="text-3xl font-bold text-blue-600">Hello Tailwind + Vite!</h1> */}

    
        
    </>
  )
}

export default App
